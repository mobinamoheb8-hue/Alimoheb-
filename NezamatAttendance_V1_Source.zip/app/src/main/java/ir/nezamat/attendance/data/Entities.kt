package ir.nezamat.attendance.data

import androidx.room.*

@Entity(tableName = "personnel")
data class Personnel(
    @PrimaryKey val code: String,
    val fullName: String,
    val photoPath: String? = null,
    val department: String = "",
    val phone: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "attendance", indices = [Index("personnelCode"), Index("timestamp")])
data class Attendance(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val personnelCode: String,
    val type: String,
    val timestamp: Long,
    val method: String = "دستی"
)

@Dao
interface PersonnelDao {
    @Query("SELECT * FROM personnel ORDER BY fullName")
    suspend fun all(): List<Personnel>
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(personnel: Personnel)
    @Update
    suspend fun update(personnel: Personnel)
    @Delete
    suspend fun delete(personnel: Personnel)
}

@Dao
interface AttendanceDao {
    @Insert
    suspend fun insert(attendance: Attendance)
    @Query("SELECT * FROM attendance ORDER BY timestamp DESC")
    suspend fun all(): List<Attendance>
}

@Database(entities = [Personnel::class, Attendance::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun personnelDao(): PersonnelDao
    abstract fun attendanceDao(): AttendanceDao
}
