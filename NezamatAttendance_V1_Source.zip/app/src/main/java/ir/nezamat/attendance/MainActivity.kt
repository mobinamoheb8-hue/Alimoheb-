package ir.nezamat.attendance

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.room.Room
import ir.nezamat.attendance.data.AppDatabase
import ir.nezamat.attendance.data.Personnel
import ir.nezamat.attendance.data.Attendance
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {
    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = Room.databaseBuilder(applicationContext, AppDatabase::class.java, "nezamat.db").build()

        setContent {
            MaterialTheme {
                val scope = rememberCoroutineScope()
                var unlocked by remember { mutableStateOf(false) }
                var password by remember { mutableStateOf("") }
                var people by remember { mutableStateOf(emptyList<Personnel>()) }
                var history by remember { mutableStateOf(emptyList<Attendance>()) }
                var tab by remember { mutableStateOf("خانه") }
                var fullName by remember { mutableStateOf("") }
                var code by remember { mutableStateOf("") }
                var department by remember { mutableStateOf("") }
                var phone by remember { mutableStateOf("") }
                var photoBitmap by remember { mutableStateOf<Bitmap?>(null) }
                var message by remember { mutableStateOf("") }

                val cameraLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.TakePicturePreview()
                ) { bitmap -> photoBitmap = bitmap }

                suspend fun refresh() {
                    people = db.personnelDao().all()
                    history = db.attendanceDao().all()
                }

                LaunchedEffect(unlocked) { if (unlocked) refresh() }

                if (!unlocked) {
                    Column(
                        Modifier.fillMaxSize().padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("سامانه هوشمند انتظامات", style = MaterialTheme.typography.headlineSmall)
                        Spacer(Modifier.height(20.dp))
                        OutlinedTextField(
                            value = password, onValueChange = { password = it },
                            label = { Text("رمز عبور") }, singleLine = true
                        )
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = {
                            if (password == "1234") { unlocked = true; message = "" }
                            else message = "رمز عبور نادرست است"
                        }) { Text("ورود به برنامه") }
                        Text(message, color = MaterialTheme.colorScheme.error)
                        Spacer(Modifier.height(8.dp))
                        Text("رمز آزمایشی: 1234", style = MaterialTheme.typography.bodySmall)
                    }
                } else {
                    Scaffold(topBar = {
                        TopAppBar(title = { Text("سامانه هوشمند انتظامات") })
                    }) { padding ->
                        Column(Modifier.padding(padding).fillMaxSize().padding(12.dp)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("خانه", "پرسنل", "تردد", "سوابق").forEach {
                                    FilterChip(selected = tab == it, onClick = { tab = it }, label = { Text(it) })
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            when (tab) {
                                "پرسنل" -> {
                                    Text("ثبت پرونده پرسنل", style = MaterialTheme.typography.titleLarge)
                                    Spacer(Modifier.height(8.dp))
                                    OutlinedTextField(fullName, { fullName = it }, label = { Text("نام و نام خانوادگی") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                    OutlinedTextField(code, { code = it }, label = { Text("کد پرسنلی (الزامی و یکتا)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                    OutlinedTextField(department, { department = it }, label = { Text("واحد / بخش") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                    OutlinedTextField(phone, { phone = it }, label = { Text("شماره تماس (اختیاری)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                    Spacer(Modifier.height(8.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Button(onClick = { cameraLauncher.launch(null) }) { Text("عکس‌برداری با دوربین") }
                                        photoBitmap?.let {
                                            Image(it.asImageBitmap(), contentDescription = "عکس پرسنل", modifier = Modifier.size(64.dp), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                                        }
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    Button(onClick = {
                                        if (fullName.isBlank() || code.isBlank()) {
                                            message = "نام و کد پرسنلی را وارد کنید"
                                        } else {
                                            scope.launch {
                                                try {
                                                    val savedPhoto = photoBitmap?.let { bitmap ->
                                                        val dir = File(filesDir, "personnel_photos").apply { mkdirs() }
                                                        val file = File(dir, "${code.trim()}.jpg")
                                                        FileOutputStream(file).use { out -> bitmap.compress(Bitmap.CompressFormat.JPEG, 88, out) }
                                                        file.absolutePath
                                                    }
                                                    db.personnelDao().insert(Personnel(
                                                        code = code.trim(), fullName = fullName.trim(),
                                                        photoPath = savedPhoto, department = department.trim(), phone = phone.trim()
                                                    ))
                                                    fullName = ""; code = ""; department = ""; phone = ""; photoBitmap = null
                                                    refresh()
                                                    message = "پرونده پرسنل ذخیره شد"
                                                } catch (e: Exception) {
                                                    message = "ذخیره انجام نشد؛ کد پرسنلی تکراری است یا خطایی رخ داده"
                                                }
                                            }
                                        }
                                    }) { Text("ذخیره پرونده") }
                                    Text(message, color = MaterialTheme.colorScheme.primary)
                                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                                    LazyColumn {
                                        items(people, key = { it.code }) { p ->
                                            ListItem(
                                                headlineContent = { Text(p.fullName) },
                                                supportingContent = { Text("کد ${p.code}  |  ${p.department}") },
                                                leadingContent = {
                                                    val bmp = p.photoPath?.let { BitmapFactory.decodeFile(it) }
                                                    if (bmp != null) Image(bmp.asImageBitmap(), null, Modifier.size(48.dp), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                                                    else Surface(Modifier.size(48.dp), shape = CircleShape, color = MaterialTheme.colorScheme.surfaceVariant) { Box(contentAlignment = Alignment.Center) { Text("؟") } }
                                                }
                                            )
                                        }
                                    }
                                }
                                "تردد" -> {
                                    Text("ثبت ورود و خروج", style = MaterialTheme.typography.titleLarge)
                                    Text("برای هر پرسنل، نوع تردد را انتخاب کنید.")
                                    LazyColumn {
                                        items(people, key = { it.code }) { p ->
                                            Column {
                                                ListItem(headlineContent = { Text(p.fullName) }, supportingContent = { Text("کد پرسنلی: ${p.code}") })
                                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                                    OutlinedButton(onClick = {
                                                        scope.launch {
                                                            db.attendanceDao().insert(Attendance(personnelCode = p.code, type = "ورود", timestamp = System.currentTimeMillis()))
                                                            refresh(); message = "ورود ${p.fullName} ثبت شد"
                                                        }
                                                    }) { Text("ثبت ورود") }
                                                    Spacer(Modifier.width(8.dp))
                                                    Button(onClick = {
                                                        scope.launch {
                                                            db.attendanceDao().insert(Attendance(personnelCode = p.code, type = "خروج", timestamp = System.currentTimeMillis()))
                                                            refresh(); message = "خروج ${p.fullName} ثبت شد"
                                                        }
                                                    }) { Text("ثبت خروج") }
                                                }
                                                HorizontalDivider()
                                            }
                                        }
                                    }
                                    Text(message, color = MaterialTheme.colorScheme.primary)
                                }
                                "سوابق" -> {
                                    Text("آخرین ترددها", style = MaterialTheme.typography.titleLarge)
                                    LazyColumn {
                                        items(history, key = { it.id }) { item ->
                                            val person = people.firstOrNull { it.code == item.personnelCode }
                                            val date = SimpleDateFormat("yyyy/MM/dd  HH:mm:ss", Locale.getDefault()).format(Date(item.timestamp))
                                            ListItem(
                                                headlineContent = { Text("${person?.fullName ?: item.personnelCode} - ${item.type}") },
                                                supportingContent = { Text(date) }
                                            )
                                            HorizontalDivider()
                                        }
                                    }
                                }
                                else -> {
                                    Text("داشبورد انتظامات", style = MaterialTheme.typography.titleLarge)
                                    Spacer(Modifier.height(12.dp))
                                    Text("تعداد پرسنل ثبت‌شده: ${people.size} نفر")
                                    Text("تعداد رکوردهای تردد: ${history.size}")
                                    Text("اطلاعات به‌صورت محلی روی همین گوشی ذخیره می‌شود.")
                                    Spacer(Modifier.height(8.dp))
                                    Text("برای افزودن پرسنل به بخش «پرسنل» و برای ثبت تردد به بخش «تردد» بروید.")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
